package com.mertaygit.linkspy.cc.api;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class LinkActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> response = new HashMap<>();
	private String message = "";
	private double exit = 0;
	private double sketchify_time = 0;
	private HashMap<String, Object> SketchifyMap = new HashMap<>();
	private double sketchify_load = 0;
	private HashMap<String, Object> SketchifyMap2 = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear8;
	private EditText EDIT_TEXT_TOKEN;
	private EditText EDIT_TEXT_URL;
	private ProgressBar progressbar1;
	private Button button1;
	private EditText EDIT_TEXT_RESULT;
	
	private RequestNetwork LinkSpy_CC;
	private RequestNetwork.RequestListener _LinkSpy_CC_request_listener;
	private SharedPreferences save;
	private TimerTask timer;
	private TimerTask timer_api;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.link);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear8 = findViewById(R.id.linear8);
		EDIT_TEXT_TOKEN = findViewById(R.id.EDIT_TEXT_TOKEN);
		EDIT_TEXT_URL = findViewById(R.id.EDIT_TEXT_URL);
		progressbar1 = findViewById(R.id.progressbar1);
		button1 = findViewById(R.id.button1);
		EDIT_TEXT_RESULT = findViewById(R.id.EDIT_TEXT_RESULT);
		LinkSpy_CC = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (EDIT_TEXT_TOKEN.getText().toString().equals("")) {
					((EditText)EDIT_TEXT_RESULT).setError("Lütfen Api kodunu girin!");
				}
				else {
					//api kodu calistirmak icin 
					LinkSpy_CC.startRequestNetwork(RequestNetworkController.GET, EDIT_TEXT_TOKEN.getText().toString().trim().concat(EDIT_TEXT_URL.getText().toString().trim()), "linkspy.cc", _LinkSpy_CC_request_listener);
					//url kismini temizle
					EDIT_TEXT_URL.setText("");
					//progressbar acik
					progressbar1.setVisibility(View.VISIBLE);
				}
			}
		});
		
		//OnTouch
		EDIT_TEXT_RESULT.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 //yaziyi kopyala
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", EDIT_TEXT_RESULT.getText().toString()));
					//ekranda gostermek
					SketchwareUtil.showMessage(getApplicationContext(), EDIT_TEXT_RESULT.getText().toString());
					SketchwareUtil.showMessage(getApplicationContext(), "Kopyalandı!");
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		_LinkSpy_CC_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try{
					response = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
					if (response.get("status").toString().equals("success")) {
						timer_api = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										EDIT_TEXT_RESULT.setText(response.get("shortUrl").toString());
										progressbar1.setVisibility(View.GONE);
									}
								});
							}
						};
						_timer.schedule(timer_api, (int)(300));
					}
					else {
						timer_api = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										message = response.get("message").toString();
										message = message.replace("[", "");
										message = message.replace("]", "");
										EDIT_TEXT_RESULT.setText(message);
										progressbar1.setVisibility(View.GONE);
									}
								});
							}
						};
						_timer.schedule(timer_api, (int)(300));
					}
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "URL Kısaltılamadı!");
				}
				//api yonlendirici
				//{"status":"success","shortUrl":"https:\/\/l4s.cc\/q\/e\/gH2\/aHR0cHM6Ly9hbmRyb3dvbGZkZXYuYmxvZ3Nwb3QuY29tLz9tPTE="}
				//Onaylanan istek
				//{"status":"error","message":"wrong url parameters"}
				//yonlendirme hatasi
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				timer_api = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								progressbar1.setVisibility(View.GONE);
								EDIT_TEXT_URL.setText(_message);
							}
						});
					}
				};
				_timer.schedule(timer_api, (int)(300));
				//api error
			}
		};
	}
	
	private void initializeLogic() {
		//design ui
		_radius_to(EDIT_TEXT_TOKEN, 100, 10, "#EEEEEE");
		_radius_to(EDIT_TEXT_URL, 100, 10, "#EEEEEE");
		_radius_to(EDIT_TEXT_RESULT, 100, 10, "#EEEEEE");
		//api kodu kaydet
		EDIT_TEXT_TOKEN.setText(save.getString("save", ""));
		//progressbar kapali
		progressbar1.setVisibility(View.GONE);
		//Toolbar back button closed
		getSupportActionBar().setDisplayHomeAsUpEnabled(false);
		//button ui
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF006DF6);
			SketchUi.setCornerRadius(d*31);
			button1.setElevation(d*5);
			android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), SketchUi, null);
			button1.setBackground(SketchUiRD);
			button1.setClickable(true);
		}
		//button Design
		EDIT_TEXT_TOKEN.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mertcn.ttf"), 0);
		EDIT_TEXT_URL.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mertcn.ttf"), 0);
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mertcn.ttf"), 0);
		EDIT_TEXT_RESULT.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mertcn.ttf"), 0);
		SketchwareUtil.showMessage(getApplicationContext(), " @mert_aygit35");
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		//api kodu kaydetme
		save.edit().putString("save", EDIT_TEXT_TOKEN.getText().toString()).commit();
	}
	
	@Override
	public void onBackPressed() {
		if (exit == 0) {
			SketchwareUtil.showMessage(getApplicationContext(), "Uygulamadan çıkmak için iki kez basın");
			exit = 1;
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							exit = 0;
						}
					});
				}
			};
			_timer.schedule(timer, (int)(1000));
		}
		else {
			finish();
		}
		//uygulamadan cikmak icin gereken yazilim
	}
	public void _radius_to(final View _view, final double _radius, final double _shadow, final String _color) {
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}